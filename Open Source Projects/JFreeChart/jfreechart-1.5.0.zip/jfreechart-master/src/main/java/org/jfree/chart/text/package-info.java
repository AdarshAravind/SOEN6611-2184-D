/**
 * Text-related classes formerly in the JCommon class library.
 */
package org.jfree.chart.text;
